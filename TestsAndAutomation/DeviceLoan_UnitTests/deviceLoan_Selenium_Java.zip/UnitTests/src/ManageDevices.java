import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.Set;
import org.openqa.selenium.By;

/**
 * This class works with the device manage page, which includes the manage devices section,
 * the history section and the loan transaction.
 * @author Anderson Uribe-Rodriguez.
 */
public class ManageDevices {
	private WebDriver driver;
	
	/**
	 * @param driver Web driver.
	 */
	public ManageDevices(WebDriver driver) {
		this.driver = driver;
	}
	
	/**
	 * Removes all accessories in the remove tab.
	 */
	void removeAccessories() {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		WebElement removeTab = driver.findElement(By.id("panel2v-label"));
		WebElement accessories = driver.findElement(By.id("removeAccessoriesCntnr"));
		WebElement submit = driver.findElement(By.cssSelector("button[value='removeAccessory']"));
			
		removeTab.click();
		
		List<WebElement> checkboxes = accessories.findElements(By.cssSelector("input[type='checkbox']"));

		for(int i = 0; i < checkboxes.size(); i++) {
			checkboxes.get(i).click();
		}
			
		submit.click();
		
		driver.switchTo().alert().accept();	
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel2v-label")));

	}
	
	/**
	 * Adds accessories in the add tab.
	 * @param accessory The accessory to add.
	 * @param scanRequiredId Whether the accessory needs to be scanned in Aleph or not.
	 * @param accessoriesQuantity The amount of the accessory to be added.
	 */
	void addAccessories(String accessory, String scanRequiredId, String accessoriesQuantity) {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		WebElement addItems = driver.findElement(By.id("panel1v-label"));
		WebElement accessoryName = driver.findElement(By.id("accessoryName"));
		WebElement quantity = driver.findElement(By.id("quantity"));
		WebElement ScanRequired0 = driver.findElement(By.id(scanRequiredId));
		WebElement submit = driver.findElement(By.cssSelector("button[value='insertAccessory']"));
		
		Actions actions = new Actions(driver);
	
		addItems.click();
		
		accessoryName.click();
		accessoryName.sendKeys(accessory);
		
		//quantity.click();
		actions.moveToElement(quantity).click().perform(); //required since regular click won't work
		quantity.sendKeys(accessoriesQuantity);
		
		ScanRequired0.click();
		
		submit.click();
		
		driver.switchTo().alert().accept();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel1v-label")));
		
	}
	
	/**
	 * Test linking all added accessories to the first device.
	 */
	void linkAccessories() {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		WebElement device1 = driver.findElement(By.id("panel3v-label"));
		device1.click();
		
		List<WebElement> accssContainer = driver.findElements(By.className("accssContainer")); 
		List<WebElement> checkboxes = accssContainer.get(1).findElements(By.cssSelector("input[type='checkbox']"));
		
		List<WebElement> submit = driver.findElements(By.cssSelector("button[value='linkItems']"));
		
		
		for(int i = 0; i < checkboxes.size(); i++) {
			checkboxes.get(i).click();
			//println("Clicked a checkbox.");
		}
		
		submit.get(0).click();
		
		driver.switchTo().alert().accept();
		println("Accessories linked to first device.");
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel3v-label")));
	}
	
	/**
	 * Add the specified devices. The method assumes that the current page viewed belongs to the device type
	 * that will be added, such as /iPad or /Laptop. 
	 * @param barcodes A set of device barcodes. The devices needs to exist in Aleph to be added.
	 * @param device The specific device to be added. 
	 */
	void addDevices(Set<String> barcodes, String device) {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		int i = 1;
		for(String barcode : barcodes) {
			WebElement addTab = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("panel1v-label")));
			addTab.click();

			WebElement barcodeInput = driver.findElement(By.id("barcode"));
			barcodeInput.click();

			barcodeInput.sendKeys(barcode);

			WebElement ipadRadio = driver.findElement(By.cssSelector("input[value='"+device+"']"));
			ipadRadio.click();

			WebElement addDevice = driver.findElement(By.cssSelector("button[value='insertDevice']"));
			addDevice.click();

			driver.switchTo().alert().accept();
			
			println("Device " + i + " added.\n");
			i++;
		}
	}
	
	/**
	 * Convenience method for linking all accessories to each device and setting
	 * device availability. The method assumes that the current page viewed belongs to the device type
	 * that will be added, such as /iPad or /Laptop.
	 */
	void linkAndAvailability() {	
		List<WebElement> accssContainer = driver.findElements(By.className("accssContainer"));
		int len = accssContainer.size();
		for (int j = 0; j < len - 1; j++) {
			accssContainer = driver.findElements(By.className("accssContainer"));
			WebElement tabsUl = driver.findElement(By.cssSelector("ul.vertical.tabs"));
			List<WebElement> tabsLi = tabsUl.findElements(By.tagName("li"));
			
			List<WebElement> addAccessory = driver.findElements(By.className("addAccessoryBtn"));

			tabsLi.get(j + 2).click(); // start clicking tabs at '[devicename][devicenumber]'
			List<WebElement> checkboxes = accssContainer.get(j+1).findElements(By.cssSelector("input[type='checkbox']"));
			
			//link accessories to the device
			for (int k = 0; k < checkboxes.size(); k++) {
				WebElement checkbox = checkboxes.get(k);
				if ( ! checkbox.isSelected() )
					checkbox.click();
			} 
			addAccessory.get(j).findElement(By.cssSelector("button[type='submit']")).click();
			driver.switchTo().alert().accept();
			
			//Set each device availability
			List<WebElement> availability = driver.findElements(By.cssSelector("input[value='Set availability']"));
			availability.get(j).click();
			driver.switchTo().alert().accept();
		}
		
		DeviceBorrow.sleep(3000); 
	}
	
	/**
	 * Convenience method for printing to the console.
	 * @param line The string to print.
	 */
	void println(Object line) {
		   System.out.println(line);
	}

}
