import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Works with the return index, device return form, device return validation form, and return success pages.
 * @author Anderson Uribe-Rodriguez
 */
public class DeviceReturn {
	private WebDriver driver;
	private Map<String, String> formData;
	private WebDriverWait wait;
	
	/**
	 * @param driver Web driver
	 * @param formData Data to use to fill the forms
	 */
	public DeviceReturn(WebDriver driver, Map<String, String> formData) {
		this.driver = driver;
		this.formData = formData;
		this.wait = new WebDriverWait(driver, 5);
	}
	
	/**
	 * Submits the iPad return form in the return index page.
	 * @param deviceNum The device number, such as iPad 1.
	 */
	void returnIpad(String deviceNum) {
		driver.findElement(By.id("iPad")).sendKeys(deviceNum);
		driver.findElement(By.id("submit-iPad")).click();
	} 
	
	/**
	 * Submits the Laptop return form in the return index page.
	 * @param deviceNum The device number, such as Laptop 1.
	 */
	void returnLaptop(String deviceNum) {
		driver.findElement(By.id("Laptop")).sendKeys(deviceNum);
		driver.findElement(By.id("submit-Laptop")).click();
	} 
	
	/**
	 * Works with the device and accessories section for the return and return validation forms.
	 * The device must have been checked-in in Aleph before this method runs.
	 */
	void deviceAndAccessories() {
		DeviceBorrow.sleep(1000);
		
		driver.findElement(By.id("deviceScan")).click();
	}
	
	/**
	 * Works with the device condition section for the return form.
	 */
	void deviceAndCondition() {				
		uploadPictures();	
		
		DeviceBorrow.sleep(5000);
		
		WebElement notes = driver.findElement(By.id("deviceInNotes"));
		notes.click();
		notes.sendKeys(formData.get("NotesIn"));
	}
	
	/**
	 * Works with the device condition section for the return validation form.
	 * Note that the conditionAccordion-label id is added by foundation 6 on page load.
	 */
	void deviceAndConditionValidate() {
		driver.findElement(By.id("conditionAccordion-label")).click();
		
		uploadPictures();	
		
		DeviceBorrow.sleep(1000); 
		
		/*
		 * Notes testing can be added here.
		 */
	}
	
	/**
	 * Uploads pictures for the back, front and home screen input.
	 */
	void uploadPictures() {		
		WebElement frontPic = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("frontPic")));
		WebElement backPic = driver.findElement(By.id("backPic"));
		WebElement homePic = driver.findElement(By.id("homePic"));

		frontPic.sendKeys(formData.get("frontPic"));
		backPic.sendKeys(formData.get("backPic"));
		homePic.sendKeys(formData.get("homePic"));
	}
	
	/**
	 * Works with the employee section of return and return validation forms.
	 * Note that the employeeAccordion-label is added by foundation 6 on page load.
	 */
	void employee() {		
		Actions actions = new Actions(driver); 
		
		DeviceBorrow.sleep(1000);
		
		//driver.findElement(By.id("employeeAccordion-label")).click(); //Uncomment this line if this accordion is closed by default, currently it is not
		
		WebElement emplBarcode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='EmployeeBarcode_In']")));
		WebElement clean = driver.findElement(By.cssSelector("input[name='clean']"));
		WebElement reset = driver.findElement(By.cssSelector("input[name='reset']"));
		WebElement charge = driver.findElement(By.cssSelector("input[name='charge']"));
		
		actions.moveToElement(clean).click().perform(); 
		actions.moveToElement(reset).click().perform();
		actions.moveToElement(charge).click().perform(); 
		
		emplBarcode.clear();
		emplBarcode.sendKeys(formData.get("emplBarcodeIn"));
	}
	
	/**
	 * Submits the return or return validation form and proceeds to the success page.
	 */
	void submitReturn() {
		driver.findElement(By.id("returnFormSubmit")).click();
		
		//driver.switchTo().alert().accept(); //uncomment if confirmation message is added for submission
	}
	
	/**
	 * Checks that the return or return validation form's submission was successful.
	 */
	void checkSubmition() {			
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("successInnerContainer")));
	}
	
	/**
	 * Fills out the return form without submission.
	 */
	void completeForm_return() {
		deviceAndAccessories();
		deviceAndCondition();
		employee();
	}
	
	/**
	 * Fills out the return validation form without submission.
	 */
	void completeForm_returnValidate() {
		deviceAndAccessories();
		deviceAndConditionValidate();
		employee();
	}
}
