import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * This class works with the borrow validation form. 
 * @author Anderson Uribe-Rodriguez
 */
public class DeviceBorrow_Validate extends DeviceBorrow {
	private WebDriver driver;
	private Map<String, String> formData;
	private WebDriverWait wait;
	
	/**
	 * @param driver Web driver
	 * @param formData Data to use to fill the form
	 */
	public DeviceBorrow_Validate(WebDriver driver, Map<String, String> formData) {
		super(driver, formData);
		this.driver = driver;
		this.formData = formData;	
		this.wait = new WebDriverWait(driver, 5);
	}
	
	/**
	 * Works with the contact section of the borrow validation form. 
	 * Makes a call to the contact method in DeviceBorrow to fill the form.
	 * Note that conditionAccordion-label id is added by foundation 6 on page load.
	 */
	void contact() {
		driver.findElement(By.id("contactAccordion_val-label")).click(); 	
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("phone")));		
		super.contact();	
		
		driver.findElement(By.id("conditionAccordion-label")).click();
	}
	
	/**
	 * Works with the device condition section.
	 * Note that device_accessories-label id is added by foundation 6 on page load.
	 */
	void deviceAndCondition() {		
		uploadPictures();
		
		WebElement notes = driver.findElement(By.id("deviceNotes"));
		notes.clear();
		notes.sendKeys(formData.get("notes"));	
		
		DeviceBorrow.sleep(1000);
		
		driver.findElement(By.id("device_accessories-label")).click();
	}
	
	/**
	 * Works with the device and accessories section. 
	 * Note that device_accessories-label id is added by foundation 6 on page load.
	 */
	void deviceAndAccesories() {
		DeviceBorrow.sleep(1000);
		driver.findElement(By.id("device_accessories-label")).click();
		
		/*
		 * Add any accessories checkboxes logic here.
		 */
		
		driver.findElement(By.id("employeeAccordion_val-label")).click();
	}
	
	/**
	 * Submits the borrow validation form to proceed to the success page.
	 * The device must still be cheched out in Aleph before this method runs.
	 */
	void submitLoan() {
		driver.findElement(By.id("borrowFormSubmit_val")).click();	
		//driver.switchTo().alert().accept(); //uncomment if confirmation message is added for submission.
	}
	
	/**
	 * Completes the borrow validation form, without submission. 
	 */
	void completeForm() {
		this.contact();
		this.deviceAndCondition();
		this.deviceAndAccesories();
		employee();
	}

}
