import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * This class works with the borrow index page, the borrow form and loan success page.
 * @author Anderson Uribe-Rodriguez
 */
public class DeviceBorrow {
	private WebDriver driver;
	private Map<String, String> formData;
	private WebDriverWait wait;
	
	/**
	 * @param driver Web driver
	 * @param formData Data to use to fill the form
	 */
	public DeviceBorrow(WebDriver driver, Map<String, String> formData) {
		this.driver = driver;
		this.formData = formData;
		this.wait = new WebDriverWait(driver, 5);
	}
	
	/**
	 * Works with the borrow index page, the student login page.
	 * @param deviceName The device type. Such as iPad.
	 */
	void loanLogin(String deviceName) {
		WebElement barcodeInput = driver.findElement(By.cssSelector("input[name='BorrowerBarcode']"));
		barcodeInput.clear();
		barcodeInput.sendKeys(formData.get("barcode"));
		
		driver.findElement(By.cssSelector("input[value='"+deviceName+"']")).click();
		
		driver.findElement(By.id("loginBorrow")).click();
		
	}
	
	/**
	 * Clicks the back button with class backBtn. 
	 */
	void goBack() {		
		WebElement goBack = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("backBtn")));	
		goBack.click();
	}
	
	/**
	 * In case what is being tested is the borrow index page and going back from the borrow form to the index page.
	 * @param deviceName The device type. Such as iPad.
	 */
	void checkBarcodeAndBack(String deviceName) {
		loanLogin(deviceName);
		goBack();
	}
	
	/**
	 * Signs the agreement and clicks the agree button to move to the  next section.
	 */
	void agreement() {		
		WebElement canvas = wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("canvas")));

		Actions actionBuilder = new Actions(driver);          
		Action drawOnCanvas = actionBuilder
		                .click(canvas)          
		                .clickAndHold(canvas)
		                .moveByOffset(120, 120)
		                .moveByOffset(20, 50)
		                .release(canvas)
		                .build();
		drawOnCanvas.perform();
	    
		driver.findElement(By.id("signAgree")).click();
	}
	
	/**
	 * Fills the contact section with all the required data.
	 */
	void contact() {		
		Actions actions = new Actions(driver);
		
		WebElement phone = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("phone")));
		WebElement email = driver.findElement(By.id("email"));
		WebElement name = driver.findElement(By.id("name"));
		WebElement barcode = driver.findElement(By.id("barcode"));
		
		actions.moveToElement(phone).click().perform(); //required, regular click won't work consistently
		
		name.clear();
		name.sendKeys(formData.get("name"));
		barcode.clear();
		barcode.sendKeys(formData.get("barcode"));
		phone.clear();
		phone.sendKeys(formData.get("phone"));
		email.clear();
		email.sendKeys(formData.get("email"));
	}
	
	/**
	 * Clicks the continue button and the following alert box.
	 */
	private void contactContinue() {
		driver.findElement(By.id("contactContinueBtn")).click();		
		driver.switchTo().alert().accept();
	}
	
	/**
	 * Fills the contact section and continues to the next section.
	 */
	void contactFillAndContinue() {
		contact();
		contactContinue();
	}
	
	/**
	 * Uploads pictures and adds notes for the device condition section.
	 */
	void deviceAndCondition() {			
		WebElement notes = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("deviceNotes")));	

		uploadPictures();	
		
		notes.sendKeys(formData.get("notes"));
	}
	
	/**
	 * Selects a device from the dropdown list. Since all devices are together in this list,
	 * the device needs to be specified.
	 * @param deviceName The device type, such as iPad. It is case sensitive
	 * @param selectDeviceNum The device number.
	 */
	private void selectDevice(String deviceName, int selectDeviceNum) {		
		String device = deviceName + " " + selectDeviceNum;
		
		WebElement select = wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("select")));	
		select.click();
				
		//List<WebElement> devices = driver.findElements(By.className("deviceName"));
		Select devices = new Select(driver.findElement(By.id("deviceSelect")));
		devices.selectByVisibleText(device);		
	}
	
	/**
	 * Fills the device and condition section and continues to the next section. 
	 * If the device has not been scanned in Aleph, this method will fail.
	 * @param deviceName The device type, such as iPad. It is case sensitive.
	 * @param selectDeviceNum The device number.
	 */
	void fillDeviceAndCondition(String deviceName, int selectDeviceNum) {
		deviceAndCondition();
		selectDevice(deviceName, selectDeviceNum);
		driver.findElement(By.id("deviceScan")).click();
	}

	/**
	 * Uploads the front, back and home screen pictures in the device and condition section.
	 */
	void uploadPictures() {		
		WebElement frontPic = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("frontPic")));
		WebElement backPic = driver.findElement(By.id("backPic"));
		WebElement homePic = driver.findElement(By.id("homePic"));

		frontPic.sendKeys(formData.get("frontPic"));
		backPic.sendKeys(formData.get("backPic"));
		homePic.sendKeys(formData.get("homePic"));
	}

	/**
	 * Clicks the button to continue to the next section.
	 * Note that this method can be further developed by selecting and unselecting accessories from the list
	 * in this section.
	 */
	void deviceAndAccesories() {		
		WebElement device = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("deviceAccessoriesBtn")));
		device.click();
	}
	
	/**
	 * Fills the employee input with a barcode.
	 */
	void employee() {		
		WebElement emplBarcode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='EmployeeBarcode_Out']")));
		emplBarcode.clear();
		emplBarcode.sendKeys(formData.get("emplBarcode"));
	}
	
	/**
	 * Submits the loan and continues to the loan success page.
	 */
	void submitLoan() {
		driver.findElement(By.id("borrowFormSubmit")).click();	
		//driver.switchTo().alert().accept(); //uncomment if confirmation message for submission is added.
	}
	
	/**
	 * Checks that the loan was submitted successfully.
	 */
	void checkSubmition() {		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("deviceName")));
	}
	
	/**
	 * Completes the entire borrow form, but does not submits it.
	 * @param deviceName The device type, such as iPad. It is case sensitive.
	 * @param selectDeviceNum The device number.
	 */
	void completeform(String deviceName, int selectDeviceNum) {
		agreement();
		contactFillAndContinue();
		fillDeviceAndCondition(deviceName, selectDeviceNum);
		deviceAndAccesories();
		employee();
	}
	
	/**
	 * Convenience method for printing to the console.
	 * @param line The string to print.
	 */
	void println(Object line) {
		   System.out.println(line);
	}
	
	/**
	 * Many times Selenium would fail when using its native wait methods. 
	 * This method is a convenience method for waiting a period of time before proceeding to the next action.
	 * @param millis The milliseconds to hang the system.
	 */
	public static void sleep(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
}
