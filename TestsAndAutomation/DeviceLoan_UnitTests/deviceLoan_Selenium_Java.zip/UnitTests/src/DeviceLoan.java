import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Implements the several classes required for testing and automating
 * the device borrow system. 
 * @author Anderson Uribe-Rodriguez
 */
public class DeviceLoan {
	private static  WebDriver driver;
	
	/*
	 * Change these instance variables below to match your setup before proceeding.
	 */
	private static final String login = "http://localhost/Libservices/index.php/auth/login";
	private static final String deviceBorrowIndex = "http://localhost/Libservices/index.php/DeviceBorrow";
	private static final String deviceReturnIndex = "http://localhost/Libservices/index.php/DeviceBorrow/DeviceBorrow_returnDevice";
	private static final String manageDevices_Ipad = "http://localhost/Libservices/index.php/DeviceManage/iPad";
	private static final String manageDevices_Laptop = "http://localhost/Libservices/index.php/DeviceManage/Laptop";
	
	private static final String chromeDriver = "C:\\wamp64\\www\\Libservices\\DeviceLoan_UnitTests\\chromedriver.exe";
	private static final String frontPic = "C:\\wamp64\\www\\Libservices\\DeviceLoan_UnitTests\\photo_for_borrow_&_return.png";
	private static final String backPic = "C:\\wamp64\\www\\Libservices\\DeviceLoan_UnitTests\\photo_for_borrow_&_return.png";
	private static final String homePic = "C:\\wamp64\\www\\Libservices\\DeviceLoan_UnitTests\\photo_for_borrow_&_return.png";

	private static final String barcode = "12345";
	private static final String email = "ess@ess.com";
	private static final String pass = "password";
	
	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver", chromeDriver);
		driver = new ChromeDriver();		
		
		File loginCookiesFile = new File("C:\\wamp64\\www\\Libservices\\Cookies.txt");
		
		/*
		 * If you wish to not go to login page during testing, use below code. 
		 * This section only needs to run once. After the file is created, it only needs to be loaded always.
		*/
		/*
		driver.get(login); //go to login page
		login(); //fill login form
		File writeCookiesFile = writeCookies(loginCookiesFile); //create cookies file
		*/
		
		/*-------
		 * Go to your domain, to a page where you don't need to sign in order to set session cookies before running tests. Does not work in local server!
		 * Alternatively, comment the next two lines and uncomment login() from the methods you want to run.
		 */
		driver.get("domain"); 
		insertCookies(loginCookiesFile);
		
		/*
		 * Uncomment the method(s)you wish to run
		 */
		//loanManyDevices("iPad", 10);
		//returnManyDevices(""iPad", 10);
		//deviceBorrow("Laptop", 1); //or "iPad", 1
		//deviceReturn("Laptop", "1"); //or "iPad" , "1"
		//manageDevices(manageDevices_Ipad, "iPad"); //or (manageDevices_Ipad, "Laptop")
		
		//driver.quit(); //Make sure to close the browser when the test is done running. Uncomment this line for automatic closing of the browser.	
	}
	
	/**
	 * Writes cookies in a file in order to not have to login for each test
	 * @param cookiesFile
	 * @return written file with cookies
	 * @throws IOException
	 */
	public static File writeCookies(File cookiesFile) throws IOException {
			cookiesFile.delete(); //In case file has been created
			cookiesFile.createNewFile();
			FileWriter fileWrite = new FileWriter(cookiesFile);
			
			for(Cookie ck : driver.manage().getCookies()) {
				fileWrite.write(ck.getName()+ //0
						";" + ck.getValue() + //1
						";" + ck.getDomain() + //2
						";" + ck.getPath() + //3
						";" + ck.getExpiry() + //4
						";" + ck.isSecure()); //5
			}
			
			fileWrite.close();
			
			return cookiesFile;
	}
	
	/***
	 * Add cookies to the current browser session. This way one can avoid going through the login page for every test. 
	 * @param cookiesFile file that holds the coodies to be inserted into a given session
	 */
	public static void insertCookies(File cookiesFile) {
		String[] cookies = new String[5];
		try(Scanner kb = new Scanner(cookiesFile)) {
			cookies = kb.nextLine().split(";");

		} catch (IOException e) {
			e.printStackTrace();
		}
		String name = cookies[0];
		String value = cookies[1];
		String domain = cookies[2];
		String path = cookies[3];
		Date expiry = null;
		if(cookies[4].equals(null)) {
			expiry = new Date();
		} else {
			SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
			try {
				expiry = format.parse(cookies[4]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		boolean isSecure = Boolean.valueOf(cookies[5]);
		
		//System.out.println(name + " " + value+ " " +domain+ " " +path+ " " +expiry+ " " +isSecure);
		
		Cookie loginCookie = new Cookie(name, value, domain, path, expiry, isSecure);
		driver.manage().addCookie(loginCookie);
		System.out.println(name + " " + value+ " " +domain+ " " +path+ " " +expiry+ " " +isSecure);

	}
	
	/**
	 * This method is the login portal, which will redirect to the borrowing system.
	 * @param email The required login email.
	 * @param password The required login password.
	 */
	public static void login() {
		WebElement emailEl = driver.findElement(By.cssSelector("input[name='identity']"));
		WebElement passwordEl = driver.findElement(By.cssSelector("input[name='password']"));

		emailEl.sendKeys(email);	
		passwordEl.sendKeys(pass);
		
		driver.findElement(By.id("submitEmailPasswd")).click();
	}
	
	/**
	 * Loan as many devices as necessary.
	 * @param deviceName For selecting the type of device to loan.
	 * @param howMany How many devices to loan.
	 */
	public static void loanManyDevices(String deviceName, int howMany) {
		for(int i = 0; i < howMany; i++) {
			deviceBorrow(deviceName, i);
		}
	}
	
	/**
	 * Return as many devices of a type as necessary.
	 * The deviceReturn method controls which devices to target.
	 * @param How many devices to return.
	 */
	public static void returnManyDevices(String deviceType, int howMany) {
		for(int i = 1; i <= howMany; i++) {
			deviceReturn(deviceType, Integer.toString(i));
		}
	}
	

	/**
	 * Loan a device as specified by the arguments. 
	 * The device must have been checked-out in Aleph before this method runs.
	 * Please refer to the DeviceBorrow class for other methods that can be used here.
	 * @param deviceName The device type, such as iPad. It is case sensitive.
	 * @param selectDeviceNum The device number.
	 */
	public static void deviceBorrow(String deviceName, int selectDeviceNum) {
		Map<String, String> formData = new HashMap<String, String>();
		
		formData.put("name", "loanTestUser");
		formData.put("barcode", barcode);
		formData.put("phone", "3472232222");
		formData.put("email", email);
		formData.put("frontPic", frontPic);
		formData.put("backPic", backPic);
		formData.put("homePic", homePic);
		formData.put("notes", "Notes for loan out");
		formData.put("emplBarcode", "2247702020268"); 
		
		DeviceBorrow loan = new DeviceBorrow(driver, formData);
		
		driver.get(deviceBorrowIndex);
		
		//login();
		
		loan.loanLogin(deviceName);	
		loan.completeform(deviceName, selectDeviceNum);
		loan.submitLoan();
		
		borrowValidate(formData);
		
		loan.checkSubmition();
		
		DeviceBorrow.sleep(10000); //Give time to view the success page
	}
	
	/**
	 * Fills out the borrow validation form if triggered by the deviceBorrow method.
	 * The borrow form must be submitted with one or more mistakes to be able to enter the validation form.
	 * @param formData Data used to fill out the validation form.
	 */
	private static void borrowValidate(Map<String, String> formData) {
		formData.replace("emplBarcode", barcode);
		DeviceBorrow_Validate loanVal = new DeviceBorrow_Validate(driver, formData);

		try {
			loanVal.checkSubmition();
		} catch(TimeoutException e) {
			loanVal.completeForm();
			loanVal.submitLoan();
			loanVal.checkSubmition(); 
		}	
	}
	
	/**
	 * Return a device as specified by the argument.
	 * The device must have been checked-in in Aleph before this method runs.
	 * Please refer to the DeviceReturn class for other methods that can be used here.
	 * @param deviceNum The number of the device. Such as, iPad 1.
	 */
	public static void deviceReturn(String deviceType, String deviceNum) {
		Map<String, String> returnData = new HashMap<String, String>();
		
		returnData.put("frontPic", frontPic);
		returnData.put("backPic", backPic);
		returnData.put("homePic", homePic);
		returnData.put("NotesIn", "Notes for loan return");
		returnData.put("emplBarcodeIn", "2247702020202"); 
		
		DeviceReturn returnLoan = new DeviceReturn(driver, returnData);
		
		driver.get(deviceReturnIndex);
		
		//login();//Comment this line if there is no login portal 
		
		if(deviceType == "iPad") {
			returnLoan.returnIpad(deviceNum);
		} else if(deviceType == "Laptop") {
			returnLoan.returnLaptop(deviceNum);
		}
		
		returnLoan.completeForm_return();	
		returnLoan.submitReturn();		
		returnValidate();
		returnLoan.checkSubmition();
		
		DeviceBorrow.sleep(5000); //Give time to view the success page
	}
	
	/**
	 * Fills out the return validation form if triggered by the deviceReturn method.
	 * The return form must be submitted with one or more mistakes to be able to enter the validation form.
	 */
	private static void returnValidate() {
		Map<String, String> returnData = new HashMap<String, String>();
		
		returnData.put("frontPic", frontPic);
		returnData.put("backPic", backPic);
		returnData.put("homePic",homePic);
		returnData.put("NotesIn", "Notes for loan return");
		returnData.put("emplBarcodeIn", barcode);
		
		DeviceReturn returnLoan = new DeviceReturn(driver, returnData);
		
		try {
			returnLoan.checkSubmition();
		} catch(TimeoutException e) {
			returnLoan.completeForm_returnValidate();
			returnLoan.submitReturn();
			returnLoan.checkSubmition();
		}	
	}

	/**
	 * Implements several methods from the ManageDevices class. Refer to this class for more details.
	 * Also of note, this method can be used for automating some time consuming tasks in the device manage page,
	 * such as adding devices and setting them all to available.
	 * @param devicePage The device manage page specific device page.
	 * @param deviceType The device type, such as iPad. It is case sensitive.
	 */
	public static void manageDevices(String devicePage, String deviceType) {
		Set<String> ipadBarcode = new LinkedHashSet<String>(Arrays.asList(
				"1", "2", "3",
				"4", "5", "6",
				"7", "8", "9",
				"10", "11" ,"12",
				"13", "14", "15", 
				"16"));
		
		Set<String> laptopBarcode = new LinkedHashSet<String>(Arrays.asList(
				"101", "102", "103",
				"104", "105", "106",
				"107", "108", "109",
				"110", "111" ,"112",
				"113", "114", "115", 
				"116"));
		
		ManageDevices manage = new ManageDevices(driver);

		driver.get(devicePage);
		
		//login(); Comment this line if there is no login portal

		/*Select which method(s) to run. Note that you can run addDevices (ipad or laptop), addAccessories, linkAndAvailability and removeAccessories in sequence*/

		if(deviceType == "Laptop") {
			manage.addDevices(laptopBarcode, deviceType); 
		} else if(deviceType == "iPad") {
			//manage.addDevices(ipadBarcode, deviceType); 
		}
		String ScanRequiredId = "ScanRequired0"; //ScanRequired0 -> no scan. ScanRequired1 -> scan required.
		String accessoriesQuantity = "16";
		manage.addAccessories("Charger", ScanRequiredId, accessoriesQuantity);
		manage.linkAndAvailability(); //for all devices
		manage.linkAccessories();	//for first device only
		manage.removeAccessories();
		
		DeviceBorrow.sleep(5000);	
	}
}//end of file
